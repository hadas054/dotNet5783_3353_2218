﻿
namespace DO;

public enum Category
{
    Dresses,
    pants,
    jackets,
    Shirts,
}

//public enum Status
//{



//}



